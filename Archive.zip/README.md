# neural-language-model

A neural language model for language modelling with variable length inputs. 

Implementation of "A neural language model" by Bengio et al

To run: 

python NLM.py 

requires python 2.7, numpy, and matplotlib. 